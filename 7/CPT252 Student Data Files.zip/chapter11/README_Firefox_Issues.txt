Greetings Students & Instructors!

I encountered an odd Quicktime/Firefox/Windows issue during work on this chapter when using the object element to configure audio and video on a Web page. 

Firefox  would not start the Quicktime plug-in when displaying a .html file from a local drive. 

However, Firefox  WOULD access Quicktime succesfully once the same file (and media file) were published to the Web. 
Firefox on the Mac always functioned perfectly. 

Just wanted to make you aware of a quirky issue. 

Best regards,
Terry Morris